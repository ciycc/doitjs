<?php
  echo $_POST["user_name"]."님 반갑습니다";
?>